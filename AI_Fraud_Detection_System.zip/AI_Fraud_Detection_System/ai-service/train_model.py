import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score
import joblib

df = pd.read_csv("dataset/creditcard.csv")

categorical_columns = [
    "merchant",
    "category",
    "location",
    "paymentMethod",
]

encoders = {}

for col in categorical_columns:
    encoder = LabelEncoder()
    df[col] = encoder.fit_transform(df[col])
    encoders[col] = encoder

X = df.drop(columns=["transactionId", "userId", "Class"])
y = df["Class"]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

model = XGBClassifier(
    n_estimators=100,
    max_depth=6,
    learning_rate=0.1,
    random_state=42
)

model.fit(X_train, y_train)

predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)

joblib.dump(model, "fraud_model.pkl")
joblib.dump(encoders, "label_encoders.pkl")

print(f"Model Accuracy: {accuracy:.4f}")
print("Model saved as fraud_model.pkl")
print("Label encoders saved as label_encoders.pkl")