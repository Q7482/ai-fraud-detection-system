from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import joblib

app = FastAPI(title="FraudShield AI Service")

model = joblib.load("fraud_model.pkl")
encoders = joblib.load("label_encoders.pkl")


class Transaction(BaseModel):
    transactionId: str
    userId: str
    amount: float
    currency: str
    transactionType: str
    merchant: str
    category: str
    location: str
    ipAddress: str
    deviceId: str
    paymentMethod: str


@app.get("/")
def home():
    return {
        "success": True,
        "message": "FraudShield AI Service Running"
    }


@app.post("/predict")
def predict(transaction: Transaction):
    merchant = transaction.merchant
    category = transaction.category
    location = transaction.location
    paymentMethod = transaction.paymentMethod

    if merchant not in encoders["merchant"].classes_:
        merchant = encoders["merchant"].classes_[0]

    if category not in encoders["category"].classes_:
        category = encoders["category"].classes_[0]

    if location not in encoders["location"].classes_:
        location = encoders["location"].classes_[0]

    if paymentMethod not in encoders["paymentMethod"].classes_:
        paymentMethod = encoders["paymentMethod"].classes_[0]

    data = pd.DataFrame([{
        "amount": transaction.amount,
        "merchant": encoders["merchant"].transform([merchant])[0],
        "category": encoders["category"].transform([category])[0],
        "location": encoders["location"].transform([location])[0],
        "paymentMethod": encoders["paymentMethod"].transform([paymentMethod])[0],
        "fraudScore": 0.0
    }])

    probability = float(model.predict_proba(data)[0][1])

    return {
        "success": True,
        "fraudScore": round(probability, 4),
        "isFraud": probability >= 0.5,
        "reason": "High Risk Transaction" if probability >= 0.5 else "Low Risk Transaction"
    }