from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pickle
import pandas as pd
from database import transactions_collection

app = FastAPI(
    title="FraudShield AI API",
    description="AI Fraud Detection Backend",
    version="1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

with open("fraud_model.pkl", "rb") as file:
    model = pickle.load(file)

class Transaction(BaseModel):
    transaction_id: str
    amount: float
    location_risk: int
    merchant_risk: int

@app.get("/")
def home():
    return {"message": "FraudShield AI Backend Running"}

@app.post("/predict")
def predict(transaction: Transaction):
    try:
        data = pd.DataFrame([{
            "amount": transaction.amount,
            "location_risk": transaction.location_risk,
            "merchant_risk": transaction.merchant_risk
        }])

        prediction = model.predict(data)[0]
        probability = model.predict_proba(data)[0][1]

        risk_score = round(probability * 100, 2)
        status = "Fraud Risk" if prediction == 1 else "Safe"

        result = {
            "transactionId": transaction.transaction_id,
            "amount": transaction.amount,
            "location_risk": transaction.location_risk,
            "merchant_risk": transaction.merchant_risk,
            "risk_score": risk_score,
            "status": status
        }

        try:
            transactions_collection.insert_one(result)
            print("Transaction saved to MongoDB")
        except Exception as e:
            print("MongoDB Error:", e)

        return {
            "transaction_id": transaction.transaction_id,
            "risk_score": risk_score,
            "status": status
        }

    except Exception as e:
        print("Prediction Error:", e)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/transactions")
def get_transactions():
    try:
        transactions = list(
            transactions_collection.find({}, {"_id": 0})
        )

        return {
            "count": len(transactions),
            "transactions": transactions
        }

    except Exception as e:
        print("MongoDB Error:", e)
        raise HTTPException(
            status_code=500,
            detail="Failed to fetch transactions"
        )