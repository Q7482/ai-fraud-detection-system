import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import pickle

data = {
    "amount": [100, 5000, 200, 9000, 150, 7000, 300, 12000],
    "location_risk": [0, 1, 0, 1, 0, 1, 0, 1],
    "merchant_risk": [0, 1, 0, 1, 0, 1, 0, 1],
    "fraud": [0, 1, 0, 1, 0, 1, 0, 1]
}

df = pd.DataFrame(data)

X = df.drop("fraud", axis=1)
y = df["fraud"]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.25,
    random_state=42
)

model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model.fit(X_train, y_train)

prediction = model.predict(X_test)

accuracy = accuracy_score(y_test, prediction)

print("Model Accuracy:", accuracy)

with open("fraud_model.pkl", "wb") as file:
    pickle.dump(model, file)

print("Model saved successfully")