"use client";

import Link from "next/link";
import {
  LayoutDashboard,
  CreditCard,
  Activity,
  ShieldAlert,
  BarChart3,
  FileText,
  Users,
  User,
  Settings,
} from "lucide-react";

const menuItems = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Transactions", href: "/transactions", icon: CreditCard },
  { name: "Monitoring", href: "/monitoring", icon: Activity },
  { name: "Alerts", href: "/alerts", icon: ShieldAlert },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Reports", href: "/reports", icon: FileText },
  { name: "Users", href: "/users", icon: Users },
  { name: "Profile", href: "/profile", icon: User },
  { name: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  return (
    <aside className="w-72 min-h-screen bg-white border-r border-gray-200 shadow-sm">
      <div className="p-6 border-b">
        <h1 className="text-2xl font-bold text-blue-700">
          FraudShield AI
        </h1>
        <p className="text-sm text-gray-500">
          Fraud Detection System
        </p>
      </div>

      <nav className="p-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;

          return (
            <Link
              key={item.name}
              href={item.href}
              className="flex items-center gap-3 rounded-lg px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 transition"
            >
              <Icon size={20} />
              <span>{item.name}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}