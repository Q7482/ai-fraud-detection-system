    "use client";

import { Bell, Search, User } from "lucide-react";

export default function Navbar() {
  return (
    <header className="h-16 bg-white border-b flex items-center justify-between px-6">
      <div className="flex items-center gap-4">
        <div>
          <h1 className="text-xl font-semibold text-gray-800">
            FraudShield AI
          </h1>
          <p className="text-xs text-gray-500">
            AI Fraud Detection System
          </p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="hidden md:flex items-center bg-gray-100 rounded-lg px-3 py-2">
          <Search size={18} className="text-gray-500" />
          <input
            type="text"
            placeholder="Search transactions..."
            className="bg-transparent outline-none px-2 text-sm"
          />
        </div>

        <button className="relative p-2 rounded-lg hover:bg-gray-100">
          <Bell size={20} />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>

        <div className="flex items-center gap-2 cursor-pointer">
          <div className="w-9 h-9 rounded-full bg-yellow-500 flex items-center justify-center">
            <User size={20} className="text-white" />
          </div>

          <div className="hidden md:block">
            <p className="text-sm font-medium text-gray-800">
              Admin
            </p>
            <p className="text-xs text-gray-500">
              Security Analyst
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}