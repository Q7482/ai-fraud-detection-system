"use client";

import { useState } from "react";
import { Brain, ShieldAlert, CheckCircle } from "lucide-react";

export default function Prediction() {
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    transaction_id: "",
    amount: "",
    location_risk: "",
    merchant_risk: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const analyzeTransaction = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await fetch(
        "http://127.0.0.1:8000/predict",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            transaction_id: form.transaction_id,
            amount: Number(form.amount),
            location_risk: Number(form.location_risk),
            merchant_risk: Number(form.merchant_risk),
          }),
        }
      );

      const data = await response.json();

      setResult(data);
    } catch {
      setError("Backend connection failed");
    }

    setLoading(false);
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800">
        AI Fraud Prediction
      </h1>

      <p className="mt-2 text-gray-600">
        Analyze transactions using trained ML model.
      </p>

      <div className="bg-white border rounded-xl p-6 mt-8 max-w-xl">
        <div className="space-y-4">
          <input
            name="transaction_id"
            placeholder="Transaction ID"
            onChange={handleChange}
            className="w-full border rounded-lg p-3"
          />

          <input
            name="amount"
            placeholder="Transaction Amount"
            onChange={handleChange}
            className="w-full border rounded-lg p-3"
          />

          <input
            name="location_risk"
            placeholder="Location Risk (0 Safe, 1 Risk)"
            onChange={handleChange}
            className="w-full border rounded-lg p-3"
          />

          <input
            name="merchant_risk"
            placeholder="Merchant Risk (0 Safe, 1 Risk)"
            onChange={handleChange}
            className="w-full border rounded-lg p-3"
          />

          <button
            onClick={analyzeTransaction}
            className="w-full bg-black text-white rounded-lg py-3 flex items-center justify-center gap-2"
          >
            <Brain size={20} />
            {loading ? "Analyzing..." : "Analyze With AI"}
          </button>
        </div>
      </div>

      {error && (
        <p className="mt-4 text-red-500">
          {error}
        </p>
      )}

      {result && (
        <div className="bg-white border rounded-xl p-6 mt-8 max-w-xl">
          <h2 className="text-xl font-semibold">
            ML Prediction Result
          </h2>

          <div className="flex items-center gap-4 mt-5">
            {result.status === "Fraud Risk" ? (
              <ShieldAlert
                size={40}
                className="text-red-500"
              />
            ) : (
              <CheckCircle
                size={40}
                className="text-green-500"
              />
            )}

            <div>
              <p className="text-gray-500">
                Risk Score
              </p>

              <p className="text-3xl font-bold">
                {result.risk_score}%
              </p>
            </div>
          </div>

          <p className="mt-4 font-medium">
            Status: {result.status}
          </p>
        </div>
      )}
    </div>
  );
}