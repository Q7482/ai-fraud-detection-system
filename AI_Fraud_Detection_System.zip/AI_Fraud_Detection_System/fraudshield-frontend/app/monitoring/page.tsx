"use client";

import { useEffect, useState } from "react";
import { Activity, AlertTriangle, ShieldCheck } from "lucide-react";

interface Transaction {
  transactionId?: string;
  transaction_id?: string;
  amount: number;
  location_risk: number;
  merchant_risk: number;
  risk_score: number;
  status: string;
}

export default function Monitoring() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await fetch(
          "http://localhost:8000/transactions"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch transactions");
        }

        const data = await response.json();
        setTransactions(data.transactions || []);
      } catch (error) {
        console.error("Monitoring Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, []);

  const fraudCount = transactions.filter(
    (txn) => txn.status === "Fraud Risk"
  ).length;

  const safeCount = transactions.filter(
    (txn) => txn.status === "Safe"
  ).length;

  const averageRisk =
    transactions.length > 0
      ? transactions.reduce(
          (sum, txn) => sum + txn.risk_score,
          0
        ) / transactions.length
      : 0;

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">
        AI Risk Monitoring
      </h1>

      <p className="mt-2 text-gray-600">
        Real-time monitoring of transaction fraud risks.
      </p>

      <div className="grid md:grid-cols-3 gap-6 mt-8">
        <div className="bg-white border rounded-xl p-6">
          <Activity className="text-blue-500" />
          <h2 className="mt-4 font-semibold">
            Total Transactions
          </h2>
          <p className="text-3xl font-bold mt-2">
            {loading ? "..." : transactions.length}
          </p>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <AlertTriangle className="text-red-500" />
          <h2 className="mt-4 font-semibold">
            Fraud Risks
          </h2>
          <p className="text-3xl font-bold mt-2">
            {loading ? "..." : fraudCount}
          </p>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <ShieldCheck className="text-green-500" />
          <h2 className="mt-4 font-semibold">
            Average Risk
          </h2>
          <p className="text-3xl font-bold mt-2">
            {loading ? "..." : `${averageRisk.toFixed(1)}%`}
          </p>
        </div>
      </div>

      <div className="mt-8 bg-white border rounded-xl p-6">
        <h2 className="text-xl font-semibold">
          Live Transaction Monitoring
        </h2>

        <div className="overflow-x-auto mt-5">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b">
                <th className="p-3">Transaction ID</th>
                <th className="p-3">Amount</th>
                <th className="p-3">Risk Score</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>

            <tbody>
              {transactions.map((txn, index) => {
                const id =
                  txn.transactionId ||
                  txn.transaction_id ||
                  `TXN-${index}`;

                return (
                  <tr
                    key={`${id}-${index}`}
                    className="border-b"
                  >
                    <td className="p-3">{id}</td>

                    <td className="p-3">
                      ${txn.amount.toLocaleString()}
                    </td>

                    <td className="p-3">
                      {txn.risk_score}%
                    </td>

                    <td className="p-3">
                      {txn.status}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {!loading && transactions.length === 0 && (
          <p className="mt-5 text-gray-500">
            No transactions available.
          </p>
        )}
      </div>

      <div className="mt-6 text-sm text-gray-500">
        Safe Transactions: {safeCount}
      </div>
    </div>
  );
}