"use client";

import { useEffect, useState } from "react";
import { AlertTriangle, CheckCircle, ShieldAlert } from "lucide-react";

interface Transaction {
  transactionId?: string;
  transaction_id?: string;
  amount: number;
  location_risk: number;
  merchant_risk: number;
  risk_score: number;
  status: string;
}

export default function Transactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await fetch(
          "http://127.0.0.1:8000/transactions"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch transactions");
        }

        const data = await response.json();
        setTransactions(data.transactions || []);
      } catch {
        setError("Unable to load transactions");
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, []);

  const highRisk = transactions.filter(
    (txn) => txn.status === "Fraud Risk"
  ).length;

  const safeTransactions = transactions.filter(
    (txn) => txn.status === "Safe"
  ).length;

  const pendingReviews = transactions.filter(
    (txn) => txn.risk_score >= 40 && txn.risk_score <= 60
  ).length;

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">
        AI Fraud Transaction Analyzer
      </h1>

      <p className="mt-2 text-gray-600">
        Analyze transactions using AI risk detection models.
      </p>

      <div className="grid md:grid-cols-3 gap-6 mt-8">
        <div className="bg-white border rounded-xl p-6">
          <ShieldAlert className="text-red-500" />
          <h2 className="mt-4 font-semibold">
            High Risk Transactions
          </h2>
          <p className="text-3xl font-bold mt-2">
            {highRisk}
          </p>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <AlertTriangle className="text-yellow-500" />
          <h2 className="mt-4 font-semibold">
            Pending Reviews
          </h2>
          <p className="text-3xl font-bold mt-2">
            {pendingReviews}
          </p>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <CheckCircle className="text-green-500" />
          <h2 className="mt-4 font-semibold">
            Safe Transactions
          </h2>
          <p className="text-3xl font-bold mt-2">
            {safeTransactions}
          </p>
        </div>
      </div>

      <div className="mt-8 bg-white border rounded-xl p-6">
        <h2 className="text-xl font-semibold">
          Transaction Analysis
        </h2>

        {loading && (
          <p className="mt-5 text-gray-600">
            Loading transactions...
          </p>
        )}

        {error && (
          <p className="mt-5 text-red-500">
            {error}
          </p>
        )}

        {!loading && !error && (
          <div className="overflow-x-auto mt-5">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b">
                  <th className="p-3">ID</th>
                  <th className="p-3">Amount</th>
                  <th className="p-3">Location Risk</th>
                  <th className="p-3">Merchant Risk</th>
                  <th className="p-3">Risk Score</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>

              <tbody>
                {transactions.map((txn, index) => {
                  const transactionId =
                    txn.transactionId ||
                    txn.transaction_id ||
                    `transaction-${index}`;

                  return (
                    <tr
                      key={`${transactionId}-${index}`}
                      className="border-b"
                    >
                      <td className="p-3">
                        {transactionId}
                      </td>

                      <td className="p-3">
                        ${txn.amount.toLocaleString()}
                      </td>

                      <td className="p-3">
                        {txn.location_risk}
                      </td>

                      <td className="p-3">
                        {txn.merchant_risk}
                      </td>

                      <td className="p-3">
                        {txn.risk_score}%
                      </td>

                      <td className="p-3">
                        {txn.status}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {!loading && !error && transactions.length === 0 && (
          <p className="mt-5 text-gray-500">
            No transactions found.
          </p>
        )}
      </div>
    </div>
  );
}