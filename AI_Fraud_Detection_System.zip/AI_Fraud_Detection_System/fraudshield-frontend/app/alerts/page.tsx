"use client";

import { useEffect, useState } from "react";
import { AlertTriangle, ShieldAlert, Clock } from "lucide-react";

interface Transaction {
  transactionId?: string;
  transaction_id?: string;
  amount: number;
  location_risk: number;
  merchant_risk: number;
  risk_score: number;
  status: string;
}

export default function Alerts() {
  const [alerts, setAlerts] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const response = await fetch(
          "http://localhost:8000/transactions"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch alerts");
        }

        const data = await response.json();

        const fraudTransactions = (data.transactions || []).filter(
          (txn: Transaction) => txn.status === "Fraud Risk"
        );

        setAlerts(fraudTransactions);
      } catch (error) {
        console.error("Alerts Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchAlerts();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">
        Fraud Alerts
      </h1>

      <p className="mt-2 text-gray-600">
        High-risk transactions detected by the AI fraud detection model.
      </p>

      <div className="grid md:grid-cols-3 gap-6 mt-8">
        <div className="bg-white border rounded-xl p-6">
          <ShieldAlert className="text-red-500" />

          <h2 className="mt-4 font-semibold">
            Active Fraud Alerts
          </h2>

          <p className="text-3xl font-bold mt-2">
            {loading ? "..." : alerts.length}
          </p>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <AlertTriangle className="text-yellow-500" />

          <h2 className="mt-4 font-semibold">
            High Risk
          </h2>

          <p className="text-3xl font-bold mt-2">
            {loading
              ? "..."
              : alerts.filter((txn) => txn.risk_score >= 80).length}
          </p>
        </div>

        <div className="bg-white border rounded-xl p-6">
          <Clock className="text-blue-500" />

          <h2 className="mt-4 font-semibold">
            Monitoring Status
          </h2>

          <p className="text-xl font-bold mt-3 text-green-600">
            Active
          </p>
        </div>
      </div>

      <div className="mt-8 bg-white border rounded-xl p-6">
        <h2 className="text-xl font-semibold">
          Active Fraud Alerts
        </h2>

        {loading && (
          <p className="mt-5 text-gray-500">
            Loading alerts...
          </p>
        )}

        {!loading && alerts.length === 0 && (
          <p className="mt-5 text-gray-500">
            No fraud alerts found.
          </p>
        )}

        {!loading && alerts.length > 0 && (
          <div className="mt-5 space-y-4">
            {alerts.map((txn, index) => {
              const id =
                txn.transactionId ||
                txn.transaction_id ||
                `TXN-${index + 1}`;

              return (
                <div
                  key={`${id}-${index}`}
                  className="border rounded-xl p-5"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">
                        Transaction {id}
                      </h3>

                      <p className="text-sm text-gray-500 mt-1">
                        Amount: ${txn.amount.toLocaleString()}
                      </p>
                    </div>

                    <span className="px-3 py-1 rounded-full text-sm font-semibold bg-red-100 text-red-600">
                      Fraud Risk
                    </span>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 mt-4 text-sm">
                    <div>
                      <span className="text-gray-500">
                        Risk Score
                      </span>

                      <p className="font-bold text-red-600">
                        {txn.risk_score}%
                      </p>
                    </div>

                    <div>
                      <span className="text-gray-500">
                        Location Risk
                      </span>

                      <p className="font-bold">
                        {txn.location_risk}
                      </p>
                    </div>

                    <div>
                      <span className="text-gray-500">
                        Merchant Risk
                      </span>

                      <p className="font-bold">
                        {txn.merchant_risk}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}