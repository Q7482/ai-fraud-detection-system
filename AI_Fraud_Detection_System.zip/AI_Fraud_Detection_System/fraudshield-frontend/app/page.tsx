"use client";

import { useEffect, useState } from "react";
import {
  ShieldCheck,
  AlertTriangle,
  Activity,
  BarChart3,
} from "lucide-react";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

interface Transaction {
  transactionId?: string;
  transaction_id?: string;
  amount: number;
  location_risk: number;
  merchant_risk: number;
  risk_score: number;
  status: string;
}

export default function Home() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await fetch(
          "http://localhost:8000/transactions"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch transactions");
        }

        const data = await response.json();
        setTransactions(data.transactions || []);
      } catch (error) {
        console.error("Dashboard API Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, []);

  const totalTransactions = transactions.length;

  const fraudDetected = transactions.filter(
    (txn) => txn.status === "Fraud Risk"
  ).length;

  const safeTransactions = transactions.filter(
    (txn) => txn.status === "Safe"
  ).length;

  const averageRiskScore =
    totalTransactions > 0
      ? transactions.reduce(
          (sum, txn) => sum + txn.risk_score,
          0
        ) / totalTransactions
      : 0;

  const stats = [
    {
      title: "Total Transactions",
      value: loading ? "..." : totalTransactions.toLocaleString(),
      icon: Activity,
    },
    {
      title: "Fraud Detected",
      value: loading ? "..." : fraudDetected.toLocaleString(),
      icon: AlertTriangle,
    },
    {
      title: "Average Risk Score",
      value: loading ? "..." : `${averageRiskScore.toFixed(1)}%`,
      icon: ShieldCheck,
    },
    {
      title: "Safe Transactions",
      value: loading ? "..." : safeTransactions.toLocaleString(),
      icon: BarChart3,
    },
  ];

  const fraudData = transactions.map((txn, index) => ({
    transaction: index + 1,
    risk: txn.risk_score,
  }));

  const recentFrauds = transactions
    .filter((txn) => txn.status === "Fraud Risk")
    .slice(-5)
    .reverse();

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">
        FraudShield AI Dashboard
      </h1>

      <p className="mt-2 text-gray-600">
        AI Powered Fraud Detection System
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
        {stats.map((item) => {
          const Icon = item.icon;

          return (
            <div
              key={item.title}
              className="bg-white rounded-xl border p-6 shadow-sm"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-sm text-gray-500">
                  {item.title}
                </h2>

                <Icon
                  size={24}
                  className="text-yellow-600"
                />
              </div>

              <p className="text-3xl font-bold mt-4 text-gray-800">
                {item.value}
              </p>
            </div>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mt-8">
        <div className="bg-white rounded-xl border p-6">
          <h2 className="text-xl font-semibold mb-4">
            Fraud Detection Trend
          </h2>

          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={fraudData}>
              <XAxis dataKey="transaction" />
              <YAxis />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="risk"
                strokeWidth={3}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border p-6">
          <h2 className="text-xl font-semibold mb-4">
            AI Risk Monitoring
          </h2>

          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={fraudData}>
              <XAxis dataKey="transaction" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="risk" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="mt-8 bg-white rounded-xl border p-6">
        <h2 className="text-xl font-semibold">
          Recent Fraud Alerts
        </h2>

        <div className="mt-4 space-y-3">
          {recentFrauds.length === 0 ? (
            <div className="border rounded-lg p-4 text-gray-500">
              No fraud alerts found.
            </div>
          ) : (
            recentFrauds.map((txn, index) => {
              const transactionId =
                txn.transactionId ||
                txn.transaction_id ||
                `Transaction-${index + 1}`;

              return (
                <div
                  key={`${transactionId}-${index}`}
                  className="border rounded-lg p-4"
                >
                  Transaction {transactionId} detected as high
                  risk with {txn.risk_score}% risk score.
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}