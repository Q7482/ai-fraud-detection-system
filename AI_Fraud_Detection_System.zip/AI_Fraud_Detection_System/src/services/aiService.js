const axios = require("axios");

const predictFraud = async (transactionData) => {
  try {
    const response = await axios.post(
      `${process.env.AI_SERVICE_URL}/predict`,
      transactionData
    );

    return response.data;
  } catch (error) {
    console.error("AI Service Error:", error.message);

    return {
      success: false,
      fraudScore: 0,
      isFraud: false,
      reason: "AI service unavailable",
    };
  }
};

module.exports = {
  predictFraud,
};