const Transaction = require("../models/Transaction");
const { predictFraud } = require("../services/aiService");

const createTransaction = async (req, res) => {
  try {
    const aiResult = await predictFraud(req.body);

    const transaction = await Transaction.create({
      ...req.body,
      fraudScore: aiResult.fraudScore || 0,
      isFraud: aiResult.isFraud || false,
      aiReason: aiResult.reason || "",
    });

    res.status(201).json({
      success: true,
      message: "Transaction processed successfully",
      data: transaction,
      ai: aiResult,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

const getTransactions = async (req, res) => {
  try {
    const transactions = await Transaction.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: transactions.length,
      data: transactions,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

const getTransactionById = async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id);

    if (!transaction) {
      return res.status(404).json({
        success: false,
        message: "Transaction not found",
      });
    }

    res.status(200).json({
      success: true,
      data: transaction,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

module.exports = {
  createTransaction,
  getTransactions,
  getTransactionById,
};