const express = require("express");
const cors = require("cors");

const transactionRoutes = require("./routes/transactionRoutes");
const { predictFraud } = require("./services/aiService");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "FraudShield AI Backend Running",
  });
});

app.get("/test-ai", async (req, res) => {
  try {
    const result = await predictFraud({
      transactionId: "TXN001",
      userId: "USER001",
      amount: 5000,
      currency: "USD",
      transactionType: "debit",
      merchant: "Amazon",
      category: "Shopping",
      location: "Karachi",
      ipAddress: "192.168.1.1",
      deviceId: "DEVICE001",
      paymentMethod: "card",
    });

    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

app.use("/api/transactions", transactionRoutes);

module.exports = app;